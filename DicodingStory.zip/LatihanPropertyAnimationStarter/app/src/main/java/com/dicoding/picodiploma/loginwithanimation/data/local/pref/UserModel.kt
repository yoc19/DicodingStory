package com.dicoding.picodiploma.loginwithanimation.data.local.pref

data class UserModel(
    val id: String,
    val name: String,
    val token: String
)